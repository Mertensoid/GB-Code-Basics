<div class="header">
	<a href="index.php">Главная</a>
	<a href="puzzle.php">Загадки</a>
	<a href="guess.html">Угадайка</a>
	<a href="guess2.html">Угадайка для двоих</a>
	<a href="passGen.php">Генератор паролей</a>
</div>