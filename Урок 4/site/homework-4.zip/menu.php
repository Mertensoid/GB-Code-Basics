<div class="header">
	<a href="index.php">Главная</a>
	<a href="puzzle.php">Загадки</a>
	<a href="guess.php">Угадайка</a>
	<a href="guess-multi.php">Угадайка (2 игрока)</a>
	<a href="generator.php">Генератор паролей</a>
</div>